#include <iostream>
#include <string>

using namespace std;

class Cifrado_V
{
  private:
  string clave;

  public:
  string alf;

  Cifrado_V();

  string cifraralf(string msg);

  string descifraralf(string msg);

  string cifrar_a(string msg);

  string descifrar_a(string msg);

}; 

Cifrado_V::Cifrado_V()
{

  clave = "Pablo Neruda";
  alf = "abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ,.:";

};

string Cifrado_V::cifraralf(string msg)
{
  int aux0,aux1,aux2;

  for(int i=0,j=0;i<msg.length(); ++i, ++j)
  {
    aux0 = alf.find(msg[i]); 

    if(!isalpha(msg[i]))
    {
      msg[i] = alf[aux0];
      j--;
    }

    else
    { 
      if(islower(msg[i]))
      {
        aux1 = alf.find(clave[j%clave.length()]);
        aux2 = (aux0+aux1)%26;
        msg[i] = alf[aux2];
      }

      else
      {
        aux1 = alf.find(clave[j%clave.length()]);
        aux2 = (aux0+aux1)%53;
        msg[i] = alf[aux2];
      }

    }
  };
  return msg;
};


string Cifrado_V::descifraralf(string msg)
{
  int aux0,aux1,aux2;

  for(int i=0,j=0;i<msg.length(); ++i, ++j)
  {
    aux0=alf.find(msg[i]);  

    if(!isalpha(msg[i]))
    {
      msg[i] = alf[aux0];
      j--;
    }
    else
    { 
      if(islower(msg[i]))
      {
        aux1 = alf.find(clave[j%clave.length()]);
        aux2 = (aux0-aux1+26) % 26;
        msg[i] = alf[aux2];
      }
      else
      {
        aux1 = alf.find(clave[j%clave.length()]);
        aux2 = (aux0-aux1+53)%53;
        msg[i] = alf[aux2];
      }

    }
  }
  return msg;
};

string Cifrado_V::cifrar_a(string msg)
{
  string sms("aqui");

  int aux0,aux1,aux2;

  for(int i=0,j=0;i<msg.length(); ++i, ++j)
  {
    if(i%10==0)
    {
      if(i!=0)
      {
        msg.insert(i,sms);
      }
    }
    aux0 = alf.find(msg[i]);  
    if(!isalpha(msg[i]))
    {
      msg[i] = alf[aux0];
      j--;
    }
    else
    { 
      if(islower(msg[i]))
      {
        aux1 = alf.find(clave[j%clave.length()]);
        aux2 = (aux0+aux1)%26;
        msg[i] = alf[aux2];
      }
      else
      {
        aux1 = alf.find(clave[j%clave.length()]);
        aux2 = (aux0+aux1)%53;
        msg[i] = alf[aux2];
      }
    }
  }
  while(msg.length()%4!=0)
  {
    msg.append("w");
  }
  return msg;
};


string Cifrado_V::descifrar_a(string msg)
{
  string sms("aqui");

  int aux,aux2,aux3;

  for(int i=0,j=0;i<msg.length(); ++i, ++j)
  {
    if(i%10==0)
    {
      if(i!=0)
      {
        msg.erase(i,3);
      }
    }
    aux=alf.find(msg[i]);  
    if(!isalpha(msg[i]))
    {
      msg[i]=alf[aux];
      j--;
    }
    else
    { 
      if(islower(msg[i]))
      {
        aux2 = alf.find(clave[j%clave.length()]);
        aux3 = (aux-aux2+26)%26;
        msg[i] = alf[aux3];
      }
      else
      {
        aux2 = alf.find(clave[j%clave.length()]);
        aux3 = (aux-aux2+53)%53;
        msg[i] = alf[aux3];
      }
    }
  }
  while(msg.length()%4!=0)
  {
    msg.erase(msg.length(),1);
  }
  return msg;
};