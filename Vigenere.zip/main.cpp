#include <iostream>
#include <string>

#include "Vigenere.h"

using namespace std;

int main()
{
  string mss,cifrar_mss,descifrar_mss;
  
  Cifrado_V cypher;

  getline(cin,mss);

  cifrar_mss=cypher.cifrar_a(mss);

  descifrar_mss=cypher.descifrar_a(cifrar_mss);


  cout<<cifrar_mss<<"\n";
  cout<<descifrar_mss<<"\n";


}