#include <iostream>
#include <cmath>

using namespace std;


int mod(int x, int y)
{
 if(x%y<0)
    return x%y+y;
  return x%y;  
}

int alg1(int a, int b)
{
  int r = mod(a, b);
  cout << "a:" << a << " " << "b:" << b << " " << "R: " << r << endl;

  if(r == 0)
    return b;
  
  else
  {
    a = b;
    b = r;
    return alg1(a, b);
  }
}

int alg2(int a, int b)
{ 
  int r = mod(a, b);cout << "a:" << a << " " << "b:" << b << " " << "R: " << r << endl;
  if(r == 0)
    return b;

  else if(r > (b / 2))
    r = b - r;

  a = b;
  b = r;
  return alg2(a, b);
}

int alg3(int a, int b)
{
  cout << "a:" << a << " " << "b:" << b << endl;
  if(b == 0)
    return a;
  
  return alg3(b, mod(a, b));
}

int alg4(int a, int b)
{
  cout << "a:" << a << " " << "b:" << b << endl;
  if(b > a)
    return alg4(b, a);
  else if(b == 0)
    return a;

  else if((mod(a, 2) == 0) && (mod(b, 2) == 0))
    return alg4((a / 2), (b / 2))*2;

  else if((mod(a, 2) == 0) && (mod(b, 2) != 0))
    return alg4((a / 2),b);
  
  else if((mod(a, 2) != 0) && (mod(b, 2) == 0))
    return alg4(a, (b / 2));
  
  else 
    return alg4(((abs(a) - abs(b)) / 2), b);
  
}

int alg5(int a, int b)
{
  int c = 1;
  while((mod(a, 2) == 0) && (mod(b, 2) == 0))
  {
    cout << "a:" << a << " " << "b:" << b << " " << "R:" << c << endl;
    a = a / 2;
    b = b / 2;
    c = 2 * c;
    cout << "a:" << a << " " << "b:" << b << " " << "R:" << c << endl;
  }
  while(a != 0)
  {
    while(mod(a, 2) == 0)
    {
      a = a / 2;
      cout << "a:" << a << " " << "b:" << b << " " << "R:" << c << endl;
    }
    while(mod(b, 2) == 0)
    {
      b = b / 2;
      cout << "a:" << a << " " << "b:" << b << " " << "R:" << c << endl;
    }
    int d = abs((a - b)) / 2;

    if(a >= b)
      a = d;
    
    else
    {
      b = d;
      cout << "a:" << a << " " << "b:" << b << " " << "R:" << c << endl;
    }
  }
  return c * b;
}

int alg6(int a, int b)
{
  while(a != b)
  {
    cout << "a:" << a << " " << "b:" << b << endl;
    if(a > b)
      a = a - b;
    
    else
      b = b - a;
    
  }
  cout << "a:" << a << " " << "b:" << b << endl;
  return a;
}

int alg7(int a, int b)
{
  int c;
  c = mod(a, b);
  cout << "a:" << a << " " << "a:" << b << endl;
  while(c > 0)
  {
    cout << "b:" << b << " " << "R: " << c << endl;
    a = b;
    b = c;
    c = mod(a, b);
  }
  cout << "b:" << b << " " << "R: " << c << endl;
  return b; 
}
void seleccion()
{
  clock_t start,endt;
  double timer;
  int a, b, Al;

  cout << "Algoritmo nro:";
  cin >> Al;

  cout << "Primer Operador(a):";
  cin >> a ;
  cout << endl;

  cout << "Segundo Operador(b):";
  cin >> b;
  cout << endl;

  
  
  cout << endl;

  int x;
  
  start = clock();

  if(Al == 1)
    x = alg1(a, b);
  
  else if(Al == 2)
    x = alg2(a, b);

  else if(Al == 3)
    x = alg3(a, b);
  
  else if(Al == 4)
    x = alg4(a, b);
  
  else if(Al == 5)
    x = alg5(a, b);
  
  else if(Al == 6)
    x = alg6(a, b);
  
  else if(Al == 7)
    x = alg7(a, b);
  
  else
    cout << "Algoritmo invalido.";

  cout <<"MCD = " << x ;

  cout << endl;

  endt = clock();

  timer = (endt - start) / (double)CLOCKS_PER_SEC;

  cout << endl << "Tiempo: " << timer << endl;
  return;
}


int main() 
{
  cout<<"Elija el algoritmo a operar"<<endl;

  seleccion();

  return 0;
};