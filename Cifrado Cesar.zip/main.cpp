#include <iostream>
#include <string.h>
#include "Cesar.h"

using namespace std;

int main()
{
  Cifrado_Cesar emisor;
  Cifrado_Cesar receptor;

  string mensaje;
  getline(cin,mensaje);

  //cout<<receptor.descifrado(emisor.cifrado(mensaje));

  string Mcifrado = emisor.cifrado(mensaje);
  //string Mdescifrado = receptor.descifrado(Mcifrado);
  
  cout << Mcifrado;
  //cout << endl << Mdescifrado;
}